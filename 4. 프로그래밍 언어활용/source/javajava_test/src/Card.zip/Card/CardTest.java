package Card;

public class CardTest {
    public static void main(String[] args) {
        Card card = new Card();
        card.member("고객1");
        card.member("고객2");
        card.member("고객3");

    }
}
